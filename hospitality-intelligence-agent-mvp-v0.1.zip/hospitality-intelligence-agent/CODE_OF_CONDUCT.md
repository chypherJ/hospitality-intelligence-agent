# Code of Conduct

Contributors are expected to be respectful, constructive and professional.

Harassment, discrimination, threats and abusive behavior are not acceptable.
