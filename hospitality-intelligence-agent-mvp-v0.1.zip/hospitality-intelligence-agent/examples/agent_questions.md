# Example agent questions

Once connected to an MCP-compatible agent, examples include:

- What is the cost of the taco_caramelo?
- What is its food-cost percentage?
- Which ingredient is limiting taco production?
- How many tacos can I produce with current inventory?
- What should I buy to restore minimum stock?
- What is the gross margin if I sell an item for 50 and its cost is 18?
- What is the yield if I start with 13.6 kg and finish with 8.8 kg?

The agent should call the corresponding tools and explain the returned values rather than inventing calculations.
