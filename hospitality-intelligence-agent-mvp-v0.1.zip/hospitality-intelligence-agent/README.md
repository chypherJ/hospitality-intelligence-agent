# Hospitality Intelligence Agent

Open-source, agent-first toolkit for hospitality, restaurants, chefs and culinary operations.

This MVP is **not a dashboard or standalone restaurant app**. It exposes deterministic hospitality tools through an MCP server so an AI agent can use them.

## MVP capabilities

- Recipe and ingredient schemas
- Deterministic recipe costing
- Food-cost percentage and gross-margin calculations
- Yield/waste calculations
- Portion calculations from available inventory
- Inventory analysis
- Purchase-list generation
- Menu-item analysis
- Demo restaurant data
- MCP tool server
- Provider-agnostic architecture

## MCP tools

- `calculate_recipe_cost`
- `calculate_food_cost`
- `calculate_yield`
- `calculate_portions`
- `analyze_inventory`
- `generate_purchase_list`
- `analyze_menu_item`
- `calculate_margin`

The calculations are performed by application code, not by the LLM.

## Quick start

Requires Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
pytest
python -m hospitality_agent.server
```

The server uses MCP over stdio, making it suitable for MCP-compatible agents/clients.

## Project structure

```text
src/hospitality_agent/
  data.py          # demo data
  models.py        # domain schemas
  calculations.py  # deterministic business logic
  tools.py         # MCP-exposed tools
  server.py        # MCP server
tests/
examples/
docs/
```

## Connecting it to an agent

The exact configuration varies by MCP client. The server command is:

```bash
python -m hospitality_agent.server
```

For production, replace the demo repository/data layer with a database or business-system adapter without changing the calculation tools.

## Open-source model

Apache-2.0. Contributions are welcome.

This project intentionally separates:
1. Open-source hospitality capabilities.
2. Private business data.
3. Commercial integrations/configurations.

Never commit API keys, restaurant credentials, customer PII, or private operational data.
