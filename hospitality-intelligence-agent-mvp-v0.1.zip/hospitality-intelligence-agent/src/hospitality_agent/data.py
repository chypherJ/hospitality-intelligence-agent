from .models import Ingredient, Recipe, RecipeIngredient, MenuItem, HospitalityData


def demo_data() -> HospitalityData:
    ingredients = {
        "pork": Ingredient("pork", "Pork shoulder", "kg", 92.0, 18.0, 5.0),
        "lard": Ingredient("lard", "Lard", "kg", 38.0, 8.0, 2.0),
        "salt": Ingredient("salt", "Salt", "kg", 24.0, 3.0, 1.0),
        "tortilla": Ingredient("tortilla", "Corn tortilla", "kg", 29.0, 10.0, 3.0),
        "onion": Ingredient("onion", "White onion", "kg", 24.0, 4.0, 1.5),
        "cilantro": Ingredient("cilantro", "Cilantro", "kg", 80.0, 0.8, 0.2),
        "lime": Ingredient("lime", "Lime", "kg", 35.0, 5.0, 1.0),
        "cheese": Ingredient("cheese", "Cheese", "kg", 145.0, 2.5, 0.8),
    }

    recipes = {
        "carnitas": Recipe(
            id="carnitas",
            name="Carnitas base",
            ingredients=[
                RecipeIngredient("pork", 10.0),
                RecipeIngredient("lard", 1.5),
                RecipeIngredient("salt", 0.18),
            ],
            yield_quantity=6.5,
            yield_unit="kg",
            waste_percent=35.0,
        ),
        "taco_carnitas": Recipe(
            id="taco_carnitas",
            name="Taco de carnitas",
            ingredients=[
                RecipeIngredient("tortilla", 0.030),
                RecipeIngredient("pork", 0.070),
                RecipeIngredient("onion", 0.010),
                RecipeIngredient("cilantro", 0.003),
                RecipeIngredient("lime", 0.010),
            ],
            yield_quantity=1.0,
            yield_unit="portion",
        ),
        "taco_caramelo": Recipe(
            id="taco_caramelo",
            name="Taco caramelo",
            ingredients=[
                RecipeIngredient("tortilla", 0.030),
                RecipeIngredient("pork", 0.070),
                RecipeIngredient("cheese", 0.025),
                RecipeIngredient("onion", 0.010),
            ],
            yield_quantity=1.0,
            yield_unit="portion",
        ),
    }

    menu_items = {
        "taco_carnitas": MenuItem("taco_carnitas", "Taco de carnitas", "taco_carnitas", 25.0),
        "taco_caramelo": MenuItem("taco_caramelo", "Taco caramelo", "taco_caramelo", 45.0),
    }

    return HospitalityData(ingredients=ingredients, recipes=recipes, menu_items=menu_items)
