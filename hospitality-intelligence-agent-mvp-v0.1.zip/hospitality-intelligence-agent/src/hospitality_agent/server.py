from mcp.server.fastmcp import FastMCP

from .tools import (
    calculate_recipe_cost,
    calculate_food_cost,
    calculate_yield,
    calculate_portions,
    analyze_inventory,
    generate_purchase_list,
    analyze_menu_item,
    calculate_margin,
)

mcp = FastMCP("hospitality-intelligence")


@mcp.tool()
def recipe_cost(recipe_id: str) -> dict:
    """Calculate deterministic recipe cost."""
    return calculate_recipe_cost(recipe_id)


@mcp.tool()
def menu_food_cost(menu_item_id: str) -> dict:
    """Calculate deterministic food cost and gross margin."""
    return calculate_food_cost(menu_item_id)


@mcp.tool()
def yield_analysis(raw_quantity: float, finished_quantity: float) -> dict:
    """Calculate yield and waste percentages."""
    return calculate_yield(raw_quantity, finished_quantity)


@mcp.tool()
def available_portions(recipe_id: str) -> dict:
    """Calculate maximum portions using current inventory."""
    return calculate_portions(recipe_id)


@mcp.tool()
def inventory_status() -> dict:
    """Analyze inventory and low-stock items."""
    return analyze_inventory()


@mcp.tool()
def purchase_list() -> dict:
    """Generate a purchase list from minimum-stock thresholds."""
    return generate_purchase_list()


@mcp.tool()
def menu_analysis(menu_item_id: str) -> dict:
    """Analyze a menu item's cost and margin."""
    return analyze_menu_item(menu_item_id)


@mcp.tool()
def gross_margin(selling_price: float, cost: float) -> dict:
    """Calculate gross margin."""
    return calculate_margin(selling_price, cost)


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
