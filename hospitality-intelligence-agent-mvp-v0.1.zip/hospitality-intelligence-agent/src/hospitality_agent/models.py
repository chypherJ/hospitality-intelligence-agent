from dataclasses import dataclass, field
from typing import Dict, List


@dataclass(frozen=True)
class Ingredient:
    id: str
    name: str
    unit: str
    unit_cost: float
    stock: float
    minimum_stock: float = 0.0


@dataclass(frozen=True)
class RecipeIngredient:
    ingredient_id: str
    quantity: float


@dataclass(frozen=True)
class Recipe:
    id: str
    name: str
    ingredients: List[RecipeIngredient]
    yield_quantity: float
    yield_unit: str
    waste_percent: float = 0.0


@dataclass(frozen=True)
class MenuItem:
    id: str
    name: str
    recipe_id: str
    selling_price: float
    portions_per_recipe: float = 1.0


@dataclass
class HospitalityData:
    ingredients: Dict[str, Ingredient] = field(default_factory=dict)
    recipes: Dict[str, Recipe] = field(default_factory=dict)
    menu_items: Dict[str, MenuItem] = field(default_factory=dict)
