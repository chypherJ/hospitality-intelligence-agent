from .models import HospitalityData


def _ingredient_cost(data: HospitalityData, ingredient_id: str, quantity: float) -> float:
    ingredient = data.ingredients[ingredient_id]
    return ingredient.unit_cost * quantity


def recipe_cost(data: HospitalityData, recipe_id: str) -> dict:
    recipe = data.recipes[recipe_id]
    lines = []
    total = 0.0

    for item in recipe.ingredients:
        cost = _ingredient_cost(data, item.ingredient_id, item.quantity)
        total += cost
        ingredient = data.ingredients[item.ingredient_id]
        lines.append({
            "ingredient_id": item.ingredient_id,
            "ingredient": ingredient.name,
            "quantity": item.quantity,
            "unit": ingredient.unit,
            "unit_cost": ingredient.unit_cost,
            "line_cost": round(cost, 2),
        })

    portions = recipe.yield_quantity
    cost_per_yield_unit = total / portions if portions else 0.0

    return {
        "recipe_id": recipe.id,
        "recipe": recipe.name,
        "total_cost": round(total, 2),
        "yield_quantity": recipe.yield_quantity,
        "yield_unit": recipe.yield_unit,
        "cost_per_yield_unit": round(cost_per_yield_unit, 2),
        "ingredients": lines,
    }


def food_cost(data: HospitalityData, menu_item_id: str) -> dict:
    item = data.menu_items[menu_item_id]
    cost = recipe_cost(data, item.recipe_id)["cost_per_yield_unit"]
    pct = (cost / item.selling_price * 100) if item.selling_price else 0.0
    margin = item.selling_price - cost
    return {
        "menu_item_id": item.id,
        "menu_item": item.name,
        "selling_price": round(item.selling_price, 2),
        "food_cost": round(cost, 2),
        "food_cost_percent": round(pct, 2),
        "gross_margin": round(margin, 2),
        "gross_margin_percent": round(margin / item.selling_price * 100, 2)
        if item.selling_price else 0.0,
    }


def yield_analysis(raw_quantity: float, finished_quantity: float) -> dict:
    if raw_quantity <= 0:
        raise ValueError("raw_quantity must be greater than zero")
    yield_percent = finished_quantity / raw_quantity * 100
    waste_percent = 100 - yield_percent
    return {
        "raw_quantity": raw_quantity,
        "finished_quantity": finished_quantity,
        "yield_percent": round(yield_percent, 2),
        "waste_percent": round(waste_percent, 2),
    }


def portions_from_inventory(data: HospitalityData, recipe_id: str) -> dict:
    recipe = data.recipes[recipe_id]
    possible = float("inf")
    limiting = None

    for item in recipe.ingredients:
        ingredient = data.ingredients[item.ingredient_id]
        if item.quantity <= 0:
            continue
        available_portions = ingredient.stock / item.quantity
        if available_portions < possible:
            possible = available_portions
            limiting = ingredient.name

    if possible == float("inf"):
        possible = 0

    return {
        "recipe_id": recipe.id,
        "recipe": recipe.name,
        "max_portions": int(possible),
        "limiting_ingredient": limiting,
    }


def inventory_analysis(data: HospitalityData) -> dict:
    low_stock = []
    healthy = []

    for ingredient in data.ingredients.values():
        item = {
            "ingredient_id": ingredient.id,
            "ingredient": ingredient.name,
            "stock": ingredient.stock,
            "unit": ingredient.unit,
            "minimum_stock": ingredient.minimum_stock,
        }
        if ingredient.stock <= ingredient.minimum_stock:
            low_stock.append(item)
        else:
            healthy.append(item)

    return {
        "low_stock": low_stock,
        "low_stock_count": len(low_stock),
        "healthy_stock_count": len(healthy),
    }


def purchase_list(data: HospitalityData) -> dict:
    items = []
    for ingredient in data.ingredients.values():
        if ingredient.stock < ingredient.minimum_stock:
            quantity = ingredient.minimum_stock - ingredient.stock
            items.append({
                "ingredient_id": ingredient.id,
                "ingredient": ingredient.name,
                "quantity_to_buy": round(quantity, 3),
                "unit": ingredient.unit,
                "estimated_cost": round(quantity * ingredient.unit_cost, 2),
            })
    return {
        "items": items,
        "estimated_total": round(sum(i["estimated_cost"] for i in items), 2),
    }


def menu_analysis(data: HospitalityData, menu_item_id: str) -> dict:
    return food_cost(data, menu_item_id)


def margin(selling_price: float, cost: float) -> dict:
    if selling_price <= 0:
        raise ValueError("selling_price must be greater than zero")
    gross_margin = selling_price - cost
    return {
        "selling_price": round(selling_price, 2),
        "cost": round(cost, 2),
        "gross_margin": round(gross_margin, 2),
        "gross_margin_percent": round(gross_margin / selling_price * 100, 2),
    }
