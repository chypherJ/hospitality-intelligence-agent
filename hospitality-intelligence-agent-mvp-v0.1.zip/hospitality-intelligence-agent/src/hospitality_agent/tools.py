from .data import demo_data
from .calculations import (
    recipe_cost,
    food_cost,
    yield_analysis,
    portions_from_inventory,
    inventory_analysis,
    purchase_list,
    menu_analysis,
    margin,
)

DATA = demo_data()


def calculate_recipe_cost(recipe_id: str) -> dict:
    """Calculate deterministic ingredient and portion costs for a recipe."""
    if recipe_id not in DATA.recipes:
        raise ValueError(f"Unknown recipe_id: {recipe_id}")
    return recipe_cost(DATA, recipe_id)


def calculate_food_cost(menu_item_id: str) -> dict:
    """Calculate food cost %, selling price and gross margin for a menu item."""
    if menu_item_id not in DATA.menu_items:
        raise ValueError(f"Unknown menu_item_id: {menu_item_id}")
    return food_cost(DATA, menu_item_id)


def calculate_yield(raw_quantity: float, finished_quantity: float) -> dict:
    """Calculate yield and waste percentages."""
    return yield_analysis(raw_quantity, finished_quantity)


def calculate_portions(recipe_id: str) -> dict:
    """Calculate maximum portions possible from current demo inventory."""
    if recipe_id not in DATA.recipes:
        raise ValueError(f"Unknown recipe_id: {recipe_id}")
    return portions_from_inventory(DATA, recipe_id)


def analyze_inventory() -> dict:
    """Analyze current inventory and identify low-stock ingredients."""
    return inventory_analysis(DATA)


def generate_purchase_list() -> dict:
    """Generate a purchase list from minimum-stock thresholds."""
    return purchase_list(DATA)


def analyze_menu_item(menu_item_id: str) -> dict:
    """Analyze food cost and margin for a menu item."""
    if menu_item_id not in DATA.menu_items:
        raise ValueError(f"Unknown menu_item_id: {menu_item_id}")
    return menu_analysis(DATA, menu_item_id)


def calculate_margin(selling_price: float, cost: float) -> dict:
    """Calculate gross margin from selling price and cost."""
    return margin(selling_price, cost)
