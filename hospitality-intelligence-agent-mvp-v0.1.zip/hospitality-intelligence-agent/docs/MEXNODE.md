# MexNode configuration layer

MexNode can package this open-source core into vertical agent configurations.

Possible commercial configuration:

**MexNode Hospitality Agent**

- Hospitality system prompt
- Tool permissions
- MCP endpoint/configuration
- Restaurant-specific schemas
- Memory strategy
- Escalation rules
- POS/WhatsApp/inventory integrations
- Deployment and support

Keep client credentials and operational data outside this repository.

The open-source toolkit provides reusable capabilities; MexNode provides configuration, integration, deployment and support.
