# Contributing

1. Fork the repository.
2. Create a feature branch.
3. Add or update tests.
4. Keep business calculations deterministic and documented.
5. Do not add credentials or private restaurant data.
6. Open a pull request with a clear description.

New hospitality tools should include tests and documentation.
