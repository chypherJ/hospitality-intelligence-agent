# Security

Do not commit:

- API keys
- passwords
- database credentials
- customer personal data
- private restaurant financial records

Use environment variables and secret managers for deployment.

Report security issues privately to the repository maintainers rather than opening a public issue with sensitive details.
