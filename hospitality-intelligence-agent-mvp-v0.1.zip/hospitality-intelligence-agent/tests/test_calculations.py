import pytest

from hospitality_agent.data import demo_data
from hospitality_agent.calculations import (
    recipe_cost,
    food_cost,
    yield_analysis,
    portions_from_inventory,
    inventory_analysis,
    purchase_list,
    margin,
)


def test_recipe_cost():
    data = demo_data()
    result = recipe_cost(data, "taco_carnitas")
    assert result["total_cost"] > 0
    assert result["cost_per_yield_unit"] == result["total_cost"]


def test_food_cost():
    data = demo_data()
    result = food_cost(data, "taco_caramelo")
    assert result["food_cost_percent"] > 0
    assert result["gross_margin"] > 0


def test_yield():
    result = yield_analysis(10, 6.5)
    assert result["yield_percent"] == 65.0
    assert result["waste_percent"] == 35.0


def test_portions():
    data = demo_data()
    result = portions_from_inventory(data, "taco_carnitas")
    assert result["max_portions"] > 0


def test_inventory():
    data = demo_data()
    result = inventory_analysis(data)
    assert "low_stock" in result


def test_purchase_list():
    data = demo_data()
    result = purchase_list(data)
    assert result["estimated_total"] >= 0


def test_margin():
    result = margin(100, 35)
    assert result["gross_margin"] == 65
    assert result["gross_margin_percent"] == 65.0


def test_invalid_yield():
    with pytest.raises(ValueError):
        yield_analysis(0, 1)
