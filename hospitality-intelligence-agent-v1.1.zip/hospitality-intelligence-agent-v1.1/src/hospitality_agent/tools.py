from .data import demo_data
from .calculations import (
    recipe_cost,
    food_cost,
    yield_analysis,
    portions_from_inventory,
    inventory_analysis,
    purchase_list,
    menu_analysis,
    margin,
)

DATA = demo_data()


def list_ingredients() -> list[dict]:
    return [
        {"id": x.id, "name": x.name, "unit": x.unit, "unit_cost": x.unit_cost, "stock": x.stock, "minimum_stock": x.minimum_stock, "category": x.category, "supplier_id": x.supplier_id}
        for x in DATA.ingredients.values()
    ]


def list_recipes() -> list[dict]:
    return [{"id": x.id, "name": x.name, "yield_quantity": x.yield_quantity, "yield_unit": x.yield_unit} for x in DATA.recipes.values()]


def list_menu_items() -> list[dict]:
    return [{"id": x.id, "name": x.name, "selling_price": x.selling_price, "category": x.category, "recipe_id": x.recipe_id} for x in DATA.menu_items.values()]


def list_suppliers() -> list[dict]:
    return [{"id": x.id, "name": x.name, "contact": x.contact} for x in DATA.suppliers.values()]


def calculate_recipe_cost(recipe_id: str) -> dict:
    if recipe_id not in DATA.recipes:
        raise ValueError(f"Unknown recipe_id: {recipe_id}")
    return recipe_cost(DATA, recipe_id)


def calculate_food_cost(menu_item_id: str) -> dict:
    if menu_item_id not in DATA.menu_items:
        raise ValueError(f"Unknown menu_item_id: {menu_item_id}")
    return food_cost(DATA, menu_item_id)


def calculate_yield(raw_quantity: float, finished_quantity: float) -> dict:
    return yield_analysis(raw_quantity, finished_quantity)


def calculate_portions(recipe_id: str) -> dict:
    if recipe_id not in DATA.recipes:
        raise ValueError(f"Unknown recipe_id: {recipe_id}")
    return portions_from_inventory(DATA, recipe_id)


def analyze_inventory() -> dict:
    return inventory_analysis(DATA)


def generate_purchase_list() -> dict:
    return purchase_list(DATA)


def analyze_menu_item(menu_item_id: str) -> dict:
    if menu_item_id not in DATA.menu_items:
        raise ValueError(f"Unknown menu_item_id: {menu_item_id}")
    return menu_analysis(DATA, menu_item_id)


def calculate_margin(selling_price: float, cost: float) -> dict:
    return margin(selling_price, cost)
