import csv
from pathlib import Path
from .base import NormalizedSale, NormalizedInventoryItem


class CSVConnector:
    """Generic CSV adapter for early pilots and systems without an API."""

    def __init__(self, sales_csv: str | None = None, inventory_csv: str | None = None):
        self.sales_csv = Path(sales_csv) if sales_csv else None
        self.inventory_csv = Path(inventory_csv) if inventory_csv else None

    def fetch_sales(self, since: str | None = None):
        if not self.sales_csv:
            return []
        with self.sales_csv.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                yield NormalizedSale(
                    external_id=row["external_id"],
                    location_id=row["location_id"],
                    menu_item_id=row["menu_item_id"],
                    quantity=float(row["quantity"]),
                    gross_amount=float(row["gross_amount"]),
                    timestamp=row["timestamp"],
                )

    def fetch_inventory(self):
        if not self.inventory_csv:
            return []
        with self.inventory_csv.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                yield NormalizedInventoryItem(
                    external_id=row["external_id"],
                    location_id=row["location_id"],
                    ingredient_id=row["ingredient_id"],
                    quantity=float(row["quantity"]),
                    unit=row["unit"],
                    unit_cost=float(row["unit_cost"]),
                )

    def healthcheck(self):
        return {
            "connector": "csv",
            "sales_configured": self.sales_csv is not None,
            "inventory_configured": self.inventory_csv is not None,
            "status": "ready",
        }
