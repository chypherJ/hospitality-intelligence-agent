from typing import Any
from urllib.request import Request, urlopen
import json

from .base import NormalizedSale, NormalizedInventoryItem


class GenericRESTConnector:
    """
    Lightweight adapter for REST APIs.

    Endpoint payloads are mapped by small normalization functions rather than
    coupling the core agent to a particular POS vendor.
    """

    def __init__(self, base_url: str, token: str | None = None):
        self.base_url = base_url.rstrip("/")
        self.token = token

    def _get(self, path: str) -> Any:
        headers = {"Accept": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        req = Request(f"{self.base_url}/{path.lstrip('/')}", headers=headers)
        with urlopen(req, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))

    def healthcheck(self):
        return {"connector": "generic-rest", "base_url": self.base_url, "status": "configured"}

    def fetch_sales(self, since: str | None = None):
        params = f"?since={since}" if since else ""
        payload = self._get(f"sales{params}")
        for row in payload:
            yield NormalizedSale(
                external_id=str(row["id"]),
                location_id=str(row["location_id"]),
                menu_item_id=str(row["menu_item_id"]),
                quantity=float(row["quantity"]),
                gross_amount=float(row["gross_amount"]),
                timestamp=str(row["timestamp"]),
            )

    def fetch_inventory(self):
        payload = self._get("inventory")
        for row in payload:
            yield NormalizedInventoryItem(
                external_id=str(row["id"]),
                location_id=str(row["location_id"]),
                ingredient_id=str(row["ingredient_id"]),
                quantity=float(row["quantity"]),
                unit=str(row["unit"]),
                unit_cost=float(row["unit_cost"]),
            )
