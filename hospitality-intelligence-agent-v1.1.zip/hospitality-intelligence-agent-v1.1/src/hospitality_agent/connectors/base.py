from dataclasses import dataclass
from typing import Any, Iterable, Protocol


@dataclass(frozen=True)
class NormalizedSale:
    external_id: str
    location_id: str
    menu_item_id: str
    quantity: float
    gross_amount: float
    timestamp: str


@dataclass(frozen=True)
class NormalizedInventoryItem:
    external_id: str
    location_id: str
    ingredient_id: str
    quantity: float
    unit: str
    unit_cost: float


class HospitalityConnector(Protocol):
    """Minimal contract every POS/ERP connector should implement."""

    def fetch_sales(self, since: str | None = None) -> Iterable[NormalizedSale]:
        ...

    def fetch_inventory(self) -> Iterable[NormalizedInventoryItem]:
        ...

    def healthcheck(self) -> dict[str, Any]:
        ...
