"""Examples showing the normalized contract expected from external systems."""

EXAMPLE_SALE = {
    "id": "POS-10001",
    "location_id": "store-01",
    "menu_item_id": "taco_caramelo",
    "quantity": 2,
    "gross_amount": 90,
    "timestamp": "2026-10-04T13:15:00-06:00",
}

EXAMPLE_INVENTORY = {
    "id": "INV-9001",
    "location_id": "store-01",
    "ingredient_id": "pork",
    "quantity": 18.0,
    "unit": "kg",
    "unit_cost": 92.0,
}
