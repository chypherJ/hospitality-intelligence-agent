"""External-system connectors and normalized hospitality data adapters."""
