from .models import (
    Ingredient,
    Recipe,
    RecipeIngredient,
    MenuItem,
    Supplier,
    HospitalityData,
)


def demo_data() -> HospitalityData:
    """Return a complete fictional Mexican restaurant dataset for demos/tests."""
    suppliers = {
        "carnes": Supplier("carnes", "Proveedor Carnes del Norte", "ventas@carnes-demo.mx"),
        "abarrotes": Supplier("abarrotes", "Central de Abarrotes MX", "compras@abarrotes-demo.mx"),
        "frescos": Supplier("frescos", "Frescos La Huerta", "ventas@frescos-demo.mx"),
        "lacteos": Supplier("lacteos", "Lácteos del Valle", "ventas@lacteos-demo.mx"),
        "panaderia": Supplier("panaderia", "Panadería Central", "ventas@pan-demo.mx"),
    }

    # Prices and stock are fictional demo values in MXN.
    ingredients = {
        "pork": Ingredient("pork", "Pork shoulder", "kg", 92.0, 18.0, 5.0, "carnes", "protein"),
        "beef": Ingredient("beef", "Beef chuck", "kg", 178.0, 8.0, 3.0, "carnes", "protein"),
        "chicken": Ingredient("chicken", "Chicken breast", "kg", 112.0, 7.0, 2.5, "carnes", "protein"),
        "bacon": Ingredient("bacon", "Bacon", "kg", 165.0, 2.0, 1.0, "carnes", "protein"),
        "lard": Ingredient("lard", "Lard", "kg", 38.0, 8.0, 2.0, "carnes", "fat"),
        "salt": Ingredient("salt", "Salt", "kg", 24.0, 3.0, 1.0, "abarrotes", "seasoning"),
        "tortilla": Ingredient("tortilla", "Corn tortilla", "kg", 29.0, 10.0, 3.0, "abarrotes", "grain"),
        "flour_tortilla": Ingredient("flour_tortilla", "Flour tortilla", "kg", 42.0, 4.0, 1.0, "abarrotes", "grain"),
        "rice": Ingredient("rice", "Rice", "kg", 34.0, 5.0, 1.5, "abarrotes", "grain"),
        "beans": Ingredient("beans", "Pinto beans", "kg", 39.0, 4.0, 1.0, "abarrotes", "legume"),
        "oil": Ingredient("oil", "Vegetable oil", "liter", 48.0, 6.0, 2.0, "abarrotes", "fat"),
        "sugar": Ingredient("sugar", "Sugar", "kg", 27.0, 3.0, 1.0, "abarrotes", "sweetener"),
        "vinegar": Ingredient("vinegar", "White vinegar", "liter", 31.0, 2.0, 0.5, "abarrotes", "acid"),
        "onion": Ingredient("onion", "White onion", "kg", 24.0, 4.0, 1.5, "frescos", "vegetable"),
        "tomato": Ingredient("tomato", "Tomato", "kg", 36.0, 5.0, 1.5, "frescos", "vegetable"),
        "garlic": Ingredient("garlic", "Garlic", "kg", 95.0, 0.8, 0.2, "frescos", "vegetable"),
        "cilantro": Ingredient("cilantro", "Cilantro", "kg", 80.0, 0.8, 0.2, "frescos", "herb"),
        "lime": Ingredient("lime", "Lime", "kg", 35.0, 5.0, 1.0, "frescos", "fruit"),
        "avocado": Ingredient("avocado", "Avocado", "kg", 85.0, 1.0, 1.5, "frescos", "fruit"),
        "jalapeno": Ingredient("jalapeno", "Jalapeño", "kg", 42.0, 1.5, 0.4, "frescos", "vegetable"),
        "cheese": Ingredient("cheese", "Melting cheese", "kg", 145.0, 2.5, 0.8, "lacteos", "dairy"),
        "cream": Ingredient("cream", "Mexican crema", "liter", 72.0, 1.2, 0.5, "lacteos", "dairy"),
        "bread": Ingredient("bread", "Burger bun", "unit", 7.5, 24.0, 12.0, "panaderia", "bakery"),
        "potato": Ingredient("potato", "Potato", "kg", 32.0, 8.0, 2.0, "frescos", "vegetable"),
    }

    recipes = {
        "carnitas": Recipe(
            id="carnitas", name="Carnitas base",
            ingredients=[RecipeIngredient("pork", 10.0), RecipeIngredient("lard", 1.5), RecipeIngredient("salt", 0.18)],
            yield_quantity=6.5, yield_unit="kg", waste_percent=35.0,
        ),
        "taco_carnitas": Recipe(
            id="taco_carnitas", name="Taco de carnitas",
            ingredients=[RecipeIngredient("tortilla", 0.030), RecipeIngredient("pork", 0.070), RecipeIngredient("onion", 0.010), RecipeIngredient("cilantro", 0.003), RecipeIngredient("lime", 0.010)],
            yield_quantity=1.0, yield_unit="portion",
        ),
        "taco_caramelo": Recipe(
            id="taco_caramelo", name="Taco caramelo",
            ingredients=[RecipeIngredient("tortilla", 0.030), RecipeIngredient("pork", 0.070), RecipeIngredient("cheese", 0.025), RecipeIngredient("onion", 0.010)],
            yield_quantity=1.0, yield_unit="portion",
        ),
        "beef_taco": Recipe(
            id="beef_taco", name="Taco de asado",
            ingredients=[RecipeIngredient("tortilla", 0.030), RecipeIngredient("beef", 0.075), RecipeIngredient("onion", 0.010), RecipeIngredient("cilantro", 0.003), RecipeIngredient("lime", 0.010)],
            yield_quantity=1.0, yield_unit="portion",
        ),
        "beans": Recipe(
            id="beans", name="Refried beans",
            ingredients=[RecipeIngredient("beans", 1.0), RecipeIngredient("lard", 0.08), RecipeIngredient("onion", 0.08), RecipeIngredient("salt", 0.015)],
            yield_quantity=1.05, yield_unit="kg", waste_percent=5.0,
        ),
        "salsa": Recipe(
            id="salsa", name="Roasted salsa",
            ingredients=[RecipeIngredient("tomato", 1.0), RecipeIngredient("onion", 0.15), RecipeIngredient("jalapeno", 0.08), RecipeIngredient("garlic", 0.03), RecipeIngredient("cilantro", 0.02), RecipeIngredient("lime", 0.05), RecipeIngredient("salt", 0.01)],
            yield_quantity=1.15, yield_unit="kg", waste_percent=14.0,
        ),
        "burger": Recipe(
            id="burger", name="House burger",
            ingredients=[RecipeIngredient("bread", 1.0), RecipeIngredient("beef", 0.160), RecipeIngredient("bacon", 0.030), RecipeIngredient("cheese", 0.025), RecipeIngredient("onion", 0.020)],
            yield_quantity=1.0, yield_unit="portion",
        ),
        "fries": Recipe(
            id="fries", name="French fries",
            ingredients=[RecipeIngredient("potato", 0.220), RecipeIngredient("oil", 0.030), RecipeIngredient("salt", 0.004)],
            yield_quantity=1.0, yield_unit="portion",
        ),
    }

    menu_items = {
        "taco_carnitas": MenuItem("taco_carnitas", "Taco de carnitas", "taco_carnitas", 25.0, category="tacos"),
        "taco_caramelo": MenuItem("taco_caramelo", "Taco caramelo", "taco_caramelo", 45.0, category="tacos"),
        "taco_asado": MenuItem("taco_asado", "Taco de asado", "beef_taco", 25.0, category="tacos"),
        "orden_carnitas": MenuItem("orden_carnitas", "Orden de carnitas", "carnitas", 150.0, category="main"),
        "frijoles": MenuItem("frijoles", "Frijoles refritos", "beans", 55.0, category="sides"),
        "salsa": MenuItem("salsa", "Salsa de la casa", "salsa", 35.0, category="sides"),
        "burger": MenuItem("burger", "House burger", "burger", 145.0, category="burger"),
        "fries": MenuItem("fries", "French fries", "fries", 65.0, category="sides"),
    }

    return HospitalityData(
        business_name="Demo Hospitality Kitchen",
        currency="MXN",
        ingredients=ingredients,
        suppliers=suppliers,
        recipes=recipes,
        menu_items=menu_items,
    )
