# Connector Architecture

The connector layer keeps the Hospitality Intelligence core independent of any POS, ERP or inventory vendor.

## Normalized flow

```text
POS / ERP / Inventory
        |
        v
Vendor Adapter
        |
        v
Normalized Hospitality Schema
        |
        v
Hospitality Tools / MCP
        |
        v
AI Agent
```

## Supported in v1.1

### CSV Connector
Useful for pilots, exports and systems without an accessible API.

### Generic REST Connector
Provides a starting point for REST APIs. Vendor-specific adapters should subclass or wrap this connector and map vendor payloads into the normalized schema.

## Future connectors

Examples:

- Toast
- Square
- Lightspeed
- Clover
- Local/Mexican POS vendors
- PostgreSQL
- ERP systems
- Custom APIs

A connector should not contain business intelligence logic. It should only authenticate, retrieve data and normalize it.

## Security

Never hard-code credentials. Use environment variables or the customer's secret manager.

For enterprise deployments, prefer OAuth2/API keys supplied by the customer's authorized administrator and store secrets outside Git.
