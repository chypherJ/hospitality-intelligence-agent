# Normalized Hospitality Data Contract

The first normalized entities are:

## Sale

- external_id
- location_id
- menu_item_id
- quantity
- gross_amount
- timestamp

## Inventory Item

- external_id
- location_id
- ingredient_id
- quantity
- unit
- unit_cost

The contract is intentionally small in v1.1. Additional entities can be added without coupling the core calculations to a vendor.

Future entities may include:

- purchase
- supplier
- recipe
- menu item
- employee
- customer
- reservation
- waste event
- production batch
