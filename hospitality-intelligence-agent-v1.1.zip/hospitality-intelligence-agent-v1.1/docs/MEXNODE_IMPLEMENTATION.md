# MexNode Enterprise Implementation

Recommended deployment sequence:

1. Discover the client's POS/ERP and available APIs.
2. Obtain authorized API credentials/scopes from the client.
3. Map vendor fields to the normalized Hospitality schema.
4. Run the connector in read-only mode.
5. Validate data reconciliation against the client's reports.
6. Activate Hospitality MCP tools.
7. Configure the client-specific agent.
8. Add write actions only after explicit validation and approval.

For a first implementation, prefer read-only access. This reduces operational risk and lets MexNode demonstrate ROI before enabling actions such as purchase orders or menu updates.
