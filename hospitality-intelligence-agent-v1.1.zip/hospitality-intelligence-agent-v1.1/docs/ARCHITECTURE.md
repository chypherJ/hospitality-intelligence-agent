# Architecture

## Principle

Agent-first, not app-first.

The open-source core exposes hospitality domain capabilities as deterministic tools. An AI agent provides natural-language orchestration.

```text
AI Agent
   |
   | MCP
   v
Hospitality Intelligence
   |
   +-- Catalog
   +-- Recipe costing
   +-- Food cost
   +-- Yield
   +-- Portions
   +-- Inventory
   +-- Purchasing
   +-- Menu analysis
   +-- Margin
```

## Separation of concerns

- `models.py`: domain structures
- `data.py`: fictional demo repository
- `calculations.py`: deterministic business rules
- `tools.py`: tool facade
- `server.py`: MCP transport and tool exposure

A production deployment can replace `data.py` with database/POS/inventory adapters while retaining the same business logic.

## v1 demo

The demo intentionally contains enough structured data for an agent to demonstrate discovery, costing, inventory and purchasing workflows without any external credentials.

## Commercial layer

Commercial products can add:

- authenticated APIs
- multi-tenant databases
- POS integrations
- WhatsApp
- reservations
- supplier integrations
- proprietary workflows
- hosted MCP
- monitoring and support

The open-source core should remain useful on its own.
