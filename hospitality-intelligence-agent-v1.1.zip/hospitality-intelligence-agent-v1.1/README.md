# Hospitality Intelligence Agent

Open-source, agent-first toolkit for hospitality, restaurants, chefs and culinary operations.

This v1 is **not a dashboard or standalone restaurant app**. It exposes deterministic hospitality capabilities through an MCP server so an AI agent can discover and invoke them.

## v1 demo dataset

The repository ships with a completely fictional Mexican restaurant dataset:

- 24 ingredients
- 5 suppliers
- 8 recipes
- 8 menu items
- inventory levels and minimum-stock thresholds
- fictional MXN costs and selling prices

No real restaurant or customer data is included.

## MCP tools

Catalog:
- `available_ingredients`
- `available_recipes`
- `available_menu_items`
- `available_suppliers`

Operations:
- `recipe_cost`
- `menu_food_cost`
- `yield_analysis`
- `available_portions`
- `inventory_status`
- `purchase_list`
- `menu_analysis`
- `gross_margin`

The calculations are performed by deterministic application code, not by the LLM.

## Quick start

Requires Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
pip install -e ".[dev]"
pytest
python -m hospitality_agent.server
```

The server uses MCP over stdio, making it suitable for MCP-compatible agents/clients.

## Example agent questions

Once connected to an MCP-compatible agent:

> What is the food cost of the Taco Caramelo?

> How many tacos can I produce with the current inventory?

> Which ingredients are below minimum stock?

> What should I purchase and what is the estimated cost?

> Which menu item has the best gross margin?

The agent should call the appropriate tools and explain returned values instead of inventing calculations.

## Architecture

```text
AI Agent
   |
   | MCP
   v
Hospitality Intelligence
   |
   +-- Recipes / ingredients
   +-- Food cost
   +-- Yield / waste
   +-- Portions
   +-- Inventory
   +-- Purchasing
   +-- Menu analysis
   +-- Margin
```

## Project structure

```text
src/hospitality_agent/
  data.py          # fictional demo dataset
  models.py        # domain schemas
  calculations.py  # deterministic business logic
  tools.py         # tool facade
  server.py        # MCP server

tests/
docs/
examples/
```

## Production direction

The next layer can replace the fictional data repository with database, POS, inventory and supplier adapters without changing the core calculation tools.

Commercial configurations can add authentication, multi-tenancy, hosted MCP, WhatsApp, POS integrations, proprietary workflows and support.

## Open-source model

Apache-2.0. Contributions are welcome.

Never commit API keys, restaurant credentials, customer PII, or private operational data.


## v1.1 Connector Layer

The v1.1 architecture adds vendor-neutral connectors so the same agent can consume data from a restaurant's existing software.

Included:
- CSV connector for pilots and exports
- Generic REST connector
- Normalized sales and inventory contracts
- Connector health checks
- Example payloads
- MexNode enterprise implementation guidance

The first production integration should normally begin in **read-only mode**, reconcile against the client's own reports, and only later enable write actions.
