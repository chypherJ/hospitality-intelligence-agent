# Example agent questions — v1

Use the catalog tools first when the agent does not know the available IDs.

- List the available menu items.
- What is the cost of the taco_caramelo recipe?
- What is the food-cost percentage of taco_caramelo?
- Which ingredient limits taco_carnitas production?
- How many taco_carnitas portions can I produce with current inventory?
- Which ingredients are below minimum stock?
- Generate the purchase list and estimated total.
- Analyze taco_asado and explain its gross margin.
- Calculate yield if I start with 13.6 kg and finish with 8.8 kg.
- Calculate gross margin for a selling price of 120 and cost of 42.
