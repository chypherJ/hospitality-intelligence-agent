from hospitality_agent.data import demo_data
from hospitality_agent.calculations import recipe_cost, food_cost, yield_analysis, portions_from_inventory, inventory_analysis, purchase_list, margin
from hospitality_agent.tools import list_ingredients, list_recipes, list_menu_items, list_suppliers


def test_demo_dataset_is_v1_sized():
    data = demo_data()
    assert len(data.ingredients) >= 20
    assert len(data.recipes) >= 5
    assert len(data.menu_items) >= 5
    assert len(data.suppliers) >= 4


def test_recipe_cost():
    result = recipe_cost(demo_data(), "taco_carnitas")
    assert result["total_cost"] > 0
    assert result["cost_per_yield_unit"] == result["total_cost"]


def test_food_cost():
    result = food_cost(demo_data(), "taco_caramelo")
    assert result["food_cost_percent"] > 0
    assert result["gross_margin"] > 0


def test_yield():
    result = yield_analysis(10, 6.5)
    assert result["yield_percent"] == 65.0
    assert result["waste_percent"] == 35.0


def test_portions():
    result = portions_from_inventory(demo_data(), "taco_carnitas")
    assert result["max_portions"] > 0
    assert result["limiting_ingredient"]


def test_inventory_and_purchase_list():
    data = demo_data()
    inventory = inventory_analysis(data)
    purchase = purchase_list(data)
    assert inventory["low_stock_count"] >= 1
    assert purchase["estimated_total"] > 0


def test_margin():
    result = margin(100, 35)
    assert result["gross_margin"] == 65
    assert result["gross_margin_percent"] == 65.0


def test_catalog_tools():
    assert len(list_ingredients()) >= 20
    assert len(list_recipes()) >= 5
    assert len(list_menu_items()) >= 5
    assert len(list_suppliers()) >= 4
