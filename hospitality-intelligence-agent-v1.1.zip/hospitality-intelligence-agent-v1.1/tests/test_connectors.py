from pathlib import Path

from hospitality_agent.connectors.csv_adapter import CSVConnector


def test_csv_connector_reads_demo_data():
    root = Path(__file__).parents[1]
    connector = CSVConnector(
        str(root / "examples" / "sales.csv"),
        str(root / "examples" / "inventory.csv"),
    )

    sales = list(connector.fetch_sales())
    inventory = list(connector.fetch_inventory())

    assert len(sales) == 2
    assert sales[0].menu_item_id == "taco_caramelo"
    assert len(inventory) == 3
    assert inventory[0].ingredient_id == "pork"


def test_connector_healthcheck():
    connector = CSVConnector()
    assert connector.healthcheck()["status"] == "ready"
